﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace modelAndView2
{
    class User: View.IDetailsModel
    {
        private int id;
        private string username;
        private int level;
        private bool status;
        private string created;

        public User(int id, string username, string created)
        {
            this.id = id;
            this.username = username;
            this.created = created;

            this.level = 1;
            this.status = true;
        }

        public int GetId()
        {
            return id;
        }
        public string GetUsername()
        {
            return username;
        }
        public int GetLevel()
        {
            return level;
        }
        public User SetLevel(int value)
        {
            level = value;
            return this;
        }
        public bool GetStatus()
        {
            return status;
        }
        public User SetStatus(bool value)
        {
            status = value;
            return this;
        }
        public string GetCreated()
        {
            return created;
        }

        public string[] GetDetails()
        {
            return new string[] 
            {
                username,
                level.ToString(),
                id.ToString(),
                status ? "Aktív" : "Inaktív",
                created
            };
        }
    }
}
