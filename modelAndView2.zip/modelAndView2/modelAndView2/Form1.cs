﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using View;

namespace modelAndView2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            TableView<User> tableView;
            tableView = new TableView<User>(new string[] {"Felhasználónév", "Szint", "Azonosító", "Állapot", "Létrehozva" }, this);

            IDetailsModel idm = new User(1, "", "");
            List<User> model = new List<User>();
            model.Add( (new User(1, "Admin", "2020.01.01")).SetLevel(2) );
            model.Add( new User(2, "Joe", "2020.01.02") );
            tableView.Update(model);
        }
    }
}
