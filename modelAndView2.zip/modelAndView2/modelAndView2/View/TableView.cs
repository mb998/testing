﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace View
{
    class TableView<T> where T:IDetailsModel
    {
        private ListView listView;
        public TableView(string[] headers, Control parent)
        {
            listView = new ListView();
            listView.View = System.Windows.Forms.View.Details;
            parent.Controls.Add(listView);

            int cellWidth = 150;
            listView.Width = 25 + cellWidth * headers.Length;

            foreach (string header in headers)
            {
                listView.Columns.Add(header, cellWidth);
            }
        }

        public void SetLocation(int x, int y)
        {
            listView.Location = new System.Drawing.Point(x, y);
        }
        public void Update(List<T> records)
        {
            listView.Items.Clear();

            foreach(T record in records)
            {
                string[] data = record.GetDetails();
                ListViewItem lvi = new ListViewItem(data[0]);

                for(int i = 1; i < listView.Columns.Count; i++)
                {
                    lvi.SubItems.Add(data[i]);
                }
                listView.Items.Add(lvi);
            }
        }
    }
}
